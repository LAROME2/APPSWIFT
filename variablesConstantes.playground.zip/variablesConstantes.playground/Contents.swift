import UIKit
import Foundation

var greeting = "Hello, playground"

var z:Int = 8

print(greeting)
print(z)


